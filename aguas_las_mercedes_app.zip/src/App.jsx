// Placeholder React component. Replace with your real code from canvas.
export default function App() {
  return <h1>Aguas Las Mercedes - App Prototipo</h1>;
}
